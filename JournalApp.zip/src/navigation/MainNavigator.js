import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createStackNavigator} from '@react-navigation/stack';
import {JournalListScreen} from '../screens/JournalListScreen';
import {CreateEntryScreen} from '../screens/CreateEntryScreen';
import {EntryDetailScreen} from '../screens/EntryDetailScreen';
import {SearchScreen} from '../screens/SearchScreen';
import {ProfileScreen} from '../screens/ProfileScreen';
import {SettingsScreen} from '../screens/SettingsScreen';
import {TabBarIcon} from '../components/TabBarIcon';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const JournalStack = () => (
  <Stack.Navigator>
    <Stack.Screen
      name="JournalList"
      component={JournalListScreen}
      options={{title: 'My Journal'}}
    />
    <Stack.Screen
      name="EntryDetail"
      component={EntryDetailScreen}
      options={{title: 'Entry Details'}}
    />
    <Stack.Screen
      name="CreateEntry"
      component={CreateEntryScreen}
      options={{title: 'New Entry'}}
    />
  </Stack.Navigator>
);

const SearchStack = () => (
  <Stack.Navigator>
    <Stack.Screen
      name="Search"
      component={SearchScreen}
      options={{title: 'Search'}}
    />
  </Stack.Navigator>
);

const ProfileStack = () => (
  <Stack.Navigator>
    <Stack.Screen
      name="Profile"
      component={ProfileScreen}
      options={{title: 'Profile'}}
    />
    <Stack.Screen
      name="Settings"
      component={SettingsScreen}
      options={{title: 'Settings'}}
    />
  </Stack.Navigator>
);

export const MainNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={({route}) => ({
        tabBarIcon: ({focused, color, size}) => (
          <TabBarIcon
            route={route}
            focused={focused}
            color={color}
            size={size}
          />
        ),
        tabBarActiveTintColor: '#0ea5e9',
        tabBarInactiveTintColor: '#64748b',
        tabBarStyle: {
          backgroundColor: '#ffffff',
          borderTopColor: '#e2e8f0',
        },
        headerShown: false,
      })}>
      <Tab.Screen
        name="Journal"
        component={JournalStack}
        options={{title: 'Journal'}}
      />
      <Tab.Screen
        name="Search"
        component={SearchStack}
        options={{title: 'Search'}}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileStack}
        options={{title: 'Profile'}}
      />
    </Tab.Navigator>
  );
};
