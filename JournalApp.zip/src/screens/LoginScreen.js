import React, {useState} from 'react';
import {View, Text, TouchableOpacity, Alert, Image} from 'react-native';
import {useDispatch} from 'react-redux';
import {signInWithGoogle} from '../store/slices/authSlice';

export const LoginScreen = () => {
  const [isLoading, setIsLoading] = useState(false);
  const dispatch = useDispatch();

  const handleGoogleSignIn = async () => {
    try {
      setIsLoading(true);
      await dispatch(signInWithGoogle()).unwrap();
    } catch (error) {
      Alert.alert('Sign In Failed', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View className="flex-1 bg-white justify-center items-center px-6">
      <View className="items-center mb-12">
        <Text className="text-4xl font-bold text-gray-900 mb-2">Journal</Text>
        <Text className="text-lg text-gray-600 text-center">
          Capture your memories, thoughts, and experiences
        </Text>
      </View>

      <View className="w-full max-w-sm">
        <TouchableOpacity
          onPress={handleGoogleSignIn}
          disabled={isLoading}
          className="bg-white border border-gray-300 rounded-lg px-6 py-4 flex-row items-center justify-center shadow-sm">
          <Image
            source={{
              uri: 'https://developers.google.com/identity/images/g-logo.png',
            }}
            className="w-5 h-5 mr-3"
          />
          <Text className="text-gray-700 font-medium text-base">
            {isLoading ? 'Signing in...' : 'Continue with Google'}
          </Text>
        </TouchableOpacity>

        <Text className="text-center text-sm text-gray-500 mt-6">
          By continuing, you agree to our Terms of Service and Privacy Policy
        </Text>
      </View>

      <View className="mt-16">
        <Text className="text-center text-sm text-gray-400">
          Your personal journal, always with you
        </Text>
      </View>
    </View>
  );
};
