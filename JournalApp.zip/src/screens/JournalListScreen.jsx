import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  Alert,
} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import {useNavigation} from '@react-navigation/native';
import {
  fetchJournalEntries,
  deleteJournalEntry,
} from '../store/slices/journalSlice';
import {JournalEntryCard} from '../components/JournalEntryCard';
import {FloatingActionButton} from '../components/FloatingActionButton';

export const JournalListScreen = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const {entries, isLoading, error} = useSelector(state => state.journal);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadEntries();
  }, []);

  const loadEntries = async () => {
    try {
      await dispatch(fetchJournalEntries()).unwrap();
    } catch (error) {
      Alert.alert('Error', 'Failed to load journal entries');
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadEntries();
    setRefreshing(false);
  };

  const handleDeleteEntry = async entryId => {
    Alert.alert('Delete Entry', 'Are you sure you want to delete this entry?', [
      {text: 'Cancel', style: 'cancel'},
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await dispatch(deleteJournalEntry(entryId)).unwrap();
          } catch (error) {
            Alert.alert('Error', 'Failed to delete entry');
          }
        },
      },
    ]);
  };

  const handleCreateEntry = () => {
    navigation.navigate('CreateEntry');
  };

  const handleEntryPress = entry => {
    navigation.navigate('EntryDetail', {entry});
  };

  const renderEntry = ({item}) => (
    <JournalEntryCard
      entry={item}
      onPress={() => handleEntryPress(item)}
      onDelete={() => handleDeleteEntry(item.id)}
    />
  );

  const renderEmptyState = () => (
    <View className="flex-1 justify-center items-center px-6">
      <Text className="text-2xl text-gray-400 mb-2">📝</Text>
      <Text className="text-xl font-semibold text-gray-600 mb-2">
        No entries yet
      </Text>
      <Text className="text-center text-gray-500 mb-6">
        Start your journaling journey by creating your first entry
      </Text>
      <TouchableOpacity
        onPress={handleCreateEntry}
        className="bg-blue-500 px-6 py-3 rounded-lg">
        <Text className="text-white font-medium">Create First Entry</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View className="flex-1 bg-gray-50">
      <FlatList
        data={entries}
        renderItem={renderEntry}
        keyExtractor={item => item.id}
        contentContainerStyle={{padding: 16}}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
        }
        ListEmptyComponent={renderEmptyState}
        showsVerticalScrollIndicator={false}
      />

      <FloatingActionButton onPress={handleCreateEntry} />
    </View>
  );
};
