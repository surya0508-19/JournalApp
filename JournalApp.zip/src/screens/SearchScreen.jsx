import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Alert,
} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import {useNavigation} from '@react-navigation/native';
import {searchJournalEntries} from '../store/slices/journalSlice';
import {JournalEntryCard} from '../components/JournalEntryCard';
import {FilterModal} from '../components/FilterModal';

export const SearchScreen = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const {entries, isLoading} = useSelector(state => state.journal);
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    keywords: '',
    tags: [],
    dateRange: null,
    location: null,
  });

  const handleSearch = async () => {
    if (!searchQuery.trim() && !filters.keywords.trim()) {
      Alert.alert('Error', 'Please enter a search term');
      return;
    }

    try {
      const searchFilters = {
        keywords: searchQuery.trim() || filters.keywords.trim(),
        tags: filters.tags,
        dateRange: filters.dateRange,
        location: filters.location,
      };

      await dispatch(searchJournalEntries(searchFilters)).unwrap();
    } catch (error) {
      Alert.alert('Error', 'Search failed');
    }
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setFilters({
      keywords: '',
      tags: [],
      dateRange: null,
      location: null,
    });
  };

  const handleApplyFilters = newFilters => {
    setFilters(newFilters);
    setShowFilters(false);
  };

  const renderEntry = ({item}) => (
    <JournalEntryCard
      entry={item}
      onPress={() => {
        navigation.navigate('EntryDetail', {entry: item});
      }}
    />
  );

  const renderEmptyState = () => (
    <View className="flex-1 justify-center items-center px-6">
      <Text className="text-2xl text-gray-400 mb-2">🔍</Text>
      <Text className="text-xl font-semibold text-gray-600 mb-2">
        No results found
      </Text>
      <Text className="text-center text-gray-500">
        Try adjusting your search terms or filters
      </Text>
    </View>
  );

  return (
    <View className="flex-1 bg-gray-50">
      {/* Search Header */}
      <View className="bg-white p-4 border-b border-gray-200">
        <View className="flex-row items-center space-x-3">
          <View className="flex-1">
            <TextInput
              className="border border-gray-300 rounded-lg px-4 py-3 text-base"
              placeholder="Search entries..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              onSubmitEditing={handleSearch}
            />
          </View>
          <TouchableOpacity
            onPress={handleSearch}
            className="bg-blue-500 px-4 py-3 rounded-lg">
            <Text className="text-white font-medium">Search</Text>
          </TouchableOpacity>
        </View>

        <View className="flex-row items-center justify-between mt-3">
          <TouchableOpacity
            onPress={() => setShowFilters(true)}
            className="flex-row items-center">
            <Text className="text-blue-500 font-medium">Filters</Text>
            <Text className="text-blue-500 ml-1">⚙️</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={handleClearSearch}>
            <Text className="text-gray-500">Clear</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Results */}
      <FlatList
        data={entries}
        renderItem={renderEntry}
        keyExtractor={item => item.id}
        contentContainerStyle={{padding: 16}}
        ListEmptyComponent={renderEmptyState}
        showsVerticalScrollIndicator={false}
      />

      {/* Filter Modal */}
      <FilterModal
        visible={showFilters}
        filters={filters}
        onApplyFilters={handleApplyFilters}
        onClose={() => setShowFilters(false)}
      />
    </View>
  );
};
