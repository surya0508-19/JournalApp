import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Alert,
  Image,
  ScrollView,
} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import {useNavigation} from '@react-navigation/native';
import {signOut} from '../store/slices/authSlice';

export const ProfileScreen = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const {user} = useSelector(state => state.auth);
  const {entries} = useSelector(state => state.journal);

  const handleSignOut = () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      {text: 'Cancel', style: 'cancel'},
      {
        text: 'Sign Out',
        style: 'destructive',
        onPress: async () => {
          try {
            await dispatch(signOut()).unwrap();
          } catch (error) {
            Alert.alert('Error', 'Failed to sign out');
          }
        },
      },
    ]);
  };

  const handleSettings = () => {
    navigation.navigate('Settings');
  };

  const handleExportData = () => {
    Alert.alert('Export Data', 'Export functionality coming soon!');
  };

  const handleSyncData = () => {
    Alert.alert('Sync Data', 'Sync functionality coming soon!');
  };

  return (
    <ScrollView className="flex-1 bg-gray-50">
      <View className="bg-white p-6 mb-4">
        {/* Profile Header */}
        <View className="items-center mb-6">
          {user?.photo ? (
            <Image
              source={{uri: user.photo}}
              className="w-20 h-20 rounded-full mb-4"
            />
          ) : (
            <View className="w-20 h-20 rounded-full bg-gray-300 items-center justify-center mb-4">
              <Text className="text-2xl text-gray-600">
                {user?.name?.charAt(0)?.toUpperCase() || 'U'}
              </Text>
            </View>
          )}

          <Text className="text-2xl font-bold text-gray-900 mb-1">
            {user?.name || 'User'}
          </Text>
          <Text className="text-gray-600">{user?.email}</Text>
        </View>

        {/* Stats */}
        <View className="bg-gray-50 rounded-lg p-4 mb-6">
          <Text className="text-lg font-semibold text-gray-900 mb-3">
            Your Journal Stats
          </Text>
          <View className="flex-row justify-between">
            <View className="items-center">
              <Text className="text-2xl font-bold text-blue-500">
                {entries.length}
              </Text>
              <Text className="text-sm text-gray-600">Total Entries</Text>
            </View>
            <View className="items-center">
              <Text className="text-2xl font-bold text-green-500">
                {entries.filter(entry => entry.isSynced).length}
              </Text>
              <Text className="text-sm text-gray-600">Synced</Text>
            </View>
            <View className="items-center">
              <Text className="text-2xl font-bold text-yellow-500">
                {entries.filter(entry => !entry.isSynced).length}
              </Text>
              <Text className="text-sm text-gray-600">Pending</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Menu Items */}
      <View className="bg-white mb-4">
        <TouchableOpacity
          onPress={handleSettings}
          className="flex-row items-center justify-between p-4 border-b border-gray-200">
          <View className="flex-row items-center">
            <Text className="text-lg mr-3">⚙️</Text>
            <Text className="text-base font-medium text-gray-900">
              Settings
            </Text>
          </View>
          <Text className="text-gray-400">›</Text>
        </TouchableOpacity>
      </View>

      {/* Sign Out */}
      <View className="bg-white mb-4">
        <TouchableOpacity
          onPress={handleSignOut}
          className="flex-row items-center justify-center p-4">
          <Text className="text-lg mr-3">🚪</Text>
          <Text className="text-base font-medium text-red-500">Sign Out</Text>
        </TouchableOpacity>
      </View>

      {/* App Info */}
      <View className="bg-white p-4 mb-8">
        <Text className="text-center text-sm text-gray-500">
          Journal App v1.0.0
        </Text>
        <Text className="text-center text-sm text-gray-500 mt-1">
          Made with ❤️ for your memories
        </Text>
      </View>
    </ScrollView>
  );
};
