import React, {useState} from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  Image,
  Dimensions,
} from 'react-native';
import {useDispatch} from 'react-redux';
import {useNavigation, useRoute} from '@react-navigation/native';
import {
  updateJournalEntry,
  deleteJournalEntry,
} from '../store/slices/journalSlice';
import {PhotoGallery} from '../components/PhotoGallery';
import {TagList} from '../components/TagList';
import {LocationDisplay} from '../components/LocationDisplay';

const {width} = Dimensions.get('window');

export const EntryDetailScreen = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const route = useRoute();
  const {entry} = route.params;
  const [isEditing, setIsEditing] = useState(false);

  const handleEdit = () => {
    navigation.navigate('CreateEntry', {entry, isEdit: true});
  };

  const handleDelete = () => {
    Alert.alert(
      'Delete Entry',
      'Are you sure you want to delete this entry? This action cannot be undone.',
      [
        {text: 'Cancel', style: 'cancel'},
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await dispatch(deleteJournalEntry(entry.id)).unwrap();
              navigation.goBack();
            } catch (error) {
              Alert.alert('Error', 'Failed to delete entry');
            }
          },
        },
      ],
    );
  };

  const formatDate = dateString => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <ScrollView className="flex-1 bg-white">
      <View className="p-4">
        {/* Header */}
        <View className="mb-6">
          <Text className="text-2xl font-bold text-gray-900 mb-2">
            {entry.title}
          </Text>
          <Text className="text-sm text-gray-500">
            {formatDate(entry.date)}
          </Text>
        </View>

        {/* Photos */}
        {entry.photos && entry.photos.length > 0 && (
          <View className="mb-6">
            <PhotoGallery photos={entry.photos} />
          </View>
        )}

        {/* Description */}
        <View className="mb-6">
          <Text className="text-lg font-semibold text-gray-900 mb-2">
            Description
          </Text>
          <Text className="text-base text-gray-700 leading-6">
            {entry.description}
          </Text>
        </View>

        {/* Location */}
        {entry.location && (
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 mb-2">
              Location
            </Text>
            <LocationDisplay location={entry.location} />
          </View>
        )}

        {/* Tags */}
        {entry.tags && entry.tags.length > 0 && (
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 mb-2">
              Tags
            </Text>
            <TagList tags={entry.tags} />
          </View>
        )}

        {/* Sync Status */}
        <View className="mb-6">
          <View className="flex-row items-center">
            <View
              className={`w-3 h-3 rounded-full mr-2 ${
                entry.isSynced ? 'bg-green-500' : 'bg-yellow-500'
              }`}
            />
            <Text className="text-sm text-gray-600">
              {entry.isSynced ? 'Synced' : 'Pending sync'}
            </Text>
          </View>
        </View>

        {/* Action Buttons */}
        <View className="flex-row space-x-4 mb-8">
          <TouchableOpacity
            onPress={handleEdit}
            className="flex-1 bg-blue-500 py-3 rounded-lg">
            <Text className="text-white text-center font-semibold">
              Edit Entry
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={handleDelete}
            className="flex-1 bg-red-500 py-3 rounded-lg">
            <Text className="text-white text-center font-semibold">Delete</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};
