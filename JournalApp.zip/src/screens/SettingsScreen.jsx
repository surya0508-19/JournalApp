import React, {useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Switch,
  Alert,
  ScrollView,
} from 'react-native';
import {useSelector} from 'react-redux';

export const SettingsScreen = () => {
  const [darkMode, setDarkMode] = useState(false);
  const [autoSync, setAutoSync] = useState(true);
  const [locationEnabled, setLocationEnabled] = useState(true);
  const [notifications, setNotifications] = useState(true);

  const handleClearCache = () => {
    Alert.alert(
      'Clear Cache',
      'This will clear all cached data. Are you sure?',
      [
        {text: 'Cancel', style: 'cancel'},
        {
          text: 'Clear',
          style: 'destructive',
          onPress: () => {
            Alert.alert('Success', 'Cache cleared successfully');
          },
        },
      ],
    );
  };

  const handleDeleteAllData = () => {
    Alert.alert(
      'Delete All Data',
      'This will permanently delete all your journal entries. This action cannot be undone.',
      [
        {text: 'Cancel', style: 'cancel'},
        {
          text: 'Delete All',
          style: 'destructive',
          onPress: () => {
            Alert.alert('Success', 'All data deleted successfully');
          },
        },
      ],
    );
  };

  return (
    <ScrollView className="flex-1 bg-gray-50">
      {/* Appearance */}
      <View className="bg-white mb-4">
        <Text className="text-lg font-semibold text-gray-900 p-4 border-b border-gray-200">
          Appearance
        </Text>

        <View className="flex-row items-center justify-between p-4">
          <View>
            <Text className="text-base font-medium text-gray-900">
              Dark Mode
            </Text>
            <Text className="text-sm text-gray-500">Switch to dark theme</Text>
          </View>
          <Switch
            value={darkMode}
            onValueChange={setDarkMode}
            trackColor={{false: '#e5e7eb', true: '#3b82f6'}}
            thumbColor={darkMode ? '#ffffff' : '#f3f4f6'}
          />
        </View>
      </View>

      {/* Sync & Storage */}
      <View className="bg-white mb-4">
        <Text className="text-lg font-semibold text-gray-900 p-4 border-b border-gray-200">
          Sync & Storage
        </Text>

        <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
          <View>
            <Text className="text-base font-medium text-gray-900">
              Auto Sync
            </Text>
            <Text className="text-sm text-gray-500">
              Automatically sync when online
            </Text>
          </View>
          <Switch
            value={autoSync}
            onValueChange={setAutoSync}
            trackColor={{false: '#e5e7eb', true: '#3b82f6'}}
            thumbColor={autoSync ? '#ffffff' : '#f3f4f6'}
          />
        </View>

        <TouchableOpacity
          onPress={handleClearCache}
          className="flex-row items-center justify-between p-4">
          <View>
            <Text className="text-base font-medium text-gray-900">
              Clear Cache
            </Text>
            <Text className="text-sm text-gray-500">Free up storage space</Text>
          </View>
          <Text className="text-gray-400">›</Text>
        </TouchableOpacity>
      </View>

      {/* Privacy */}
      <View className="bg-white mb-4">
        <Text className="text-lg font-semibold text-gray-900 p-4 border-b border-gray-200">
          Privacy
        </Text>

        <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
          <View>
            <Text className="text-base font-medium text-gray-900">
              Location Services
            </Text>
            <Text className="text-sm text-gray-500">
              Automatically add location to entries
            </Text>
          </View>
          <Switch
            value={locationEnabled}
            onValueChange={setLocationEnabled}
            trackColor={{false: '#e5e7eb', true: '#3b82f6'}}
            thumbColor={locationEnabled ? '#ffffff' : '#f3f4f6'}
          />
        </View>

        <View className="flex-row items-center justify-between p-4">
          <View>
            <Text className="text-base font-medium text-gray-900">
              Notifications
            </Text>
            <Text className="text-sm text-gray-500">
              Receive reminders and updates
            </Text>
          </View>
          <Switch
            value={notifications}
            onValueChange={setNotifications}
            trackColor={{false: '#e5e7eb', true: '#3b82f6'}}
            thumbColor={notifications ? '#ffffff' : '#f3f4f6'}
          />
        </View>
      </View>

      {/* Data Management */}
      <View className="bg-white mb-4">
        <Text className="text-lg font-semibold text-gray-900 p-4 border-b border-gray-200">
          Data Management
        </Text>

        <TouchableOpacity
          onPress={handleDeleteAllData}
          className="flex-row items-center justify-between p-4">
          <View>
            <Text className="text-base font-medium text-red-500">
              Delete All Data
            </Text>
            <Text className="text-sm text-gray-500">
              Permanently delete all entries
            </Text>
          </View>
          <Text className="text-gray-400">›</Text>
        </TouchableOpacity>
      </View>

      {/* About */}
      <View className="bg-white mb-8">
        <Text className="text-lg font-semibold text-gray-900 p-4 border-b border-gray-200">
          About
        </Text>

        <View className="p-4">
          <Text className="text-base text-gray-900 mb-2">Journal App</Text>
          <Text className="text-sm text-gray-500 mb-4">Version 1.0.0</Text>
          <Text className="text-sm text-gray-500">
            A beautiful and secure journaling app that keeps your memories safe
            and organized.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};
