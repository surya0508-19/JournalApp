import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import {useDispatch} from 'react-redux';
import {useNavigation, useRoute} from '@react-navigation/native';
import {
  createJournalEntry,
  updateJournalEntry,
} from '../store/slices/journalSlice';
import {PhotoSelector} from '../components/PhotoSelector';
import {LocationSelector} from '../components/LocationSelector';
import {TagInput} from '../components/TagInput';

export const CreateEntryScreen = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const route = useRoute();
  const {entry, isEdit} = route.params || {};

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [photos, setPhotos] = useState([]);
  const [location, setLocation] = useState(null);
  const [tags, setTags] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  // Initialize form with existing entry data when editing
  useEffect(() => {
    if (isEdit && entry) {
      setTitle(entry.title || '');
      setDescription(entry.description || '');
      setPhotos(entry.photos || []);
      setLocation(entry.location || null);
      setTags(entry.tags || []);
    }
  }, [isEdit, entry]);

  const handleSave = async () => {
    if (!title.trim()) {
      Alert.alert('Error', 'Please enter a title');
      return;
    }

    if (!description.trim()) {
      Alert.alert('Error', 'Please enter a description');
      return;
    }

    try {
      setIsLoading(true);

      if (isEdit && entry) {
        // Update existing entry
        const updates = {
          title: title.trim(),
          description: description.trim(),
          photos,
          location,
          tags,
        };

        await dispatch(updateJournalEntry({id: entry.id, updates})).unwrap();
        Alert.alert('Success', 'Entry updated successfully');
      } else {
        // Create new entry
        const entryData = {
          title: title.trim(),
          description: description.trim(),
          photos,
          location,
          tags,
          date: new Date().toISOString(),
        };

        await dispatch(createJournalEntry(entryData)).unwrap();
        Alert.alert('Success', 'Entry created successfully');
      }

      navigation.goBack();
    } catch (error) {
      Alert.alert(
        'Error',
        isEdit ? 'Failed to update entry' : 'Failed to create entry',
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddPhoto = newPhotos => {
    const totalPhotos = photos.length + newPhotos.length;
    if (totalPhotos > 5) {
      Alert.alert('Error', 'Maximum 5 photos allowed per entry');
      return;
    }
    setPhotos([...photos, ...newPhotos]);
  };

  const handleRemovePhoto = photoId => {
    setPhotos(photos.filter(photo => photo.id !== photoId));
  };

  return (
    <KeyboardAvoidingView
      className="flex-1 bg-white"
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView className="flex-1 px-4">
        <View className="py-4">
          <Text className="text-lg font-semibold text-gray-900 mb-2">
            Title
          </Text>
          <TextInput
            className="border border-gray-300 rounded-lg px-4 py-3 text-base"
            placeholder="Enter entry title..."
            value={title}
            onChangeText={setTitle}
            maxLength={100}
          />
        </View>

        <View className="py-4">
          <Text className="text-lg font-semibold text-gray-900 mb-2">
            Description
          </Text>
          <TextInput
            className="border border-gray-300 rounded-lg px-4 py-3 text-base min-h-[120px]"
            placeholder="What's on your mind?"
            value={description}
            onChangeText={setDescription}
            multiline
            textAlignVertical="top"
            maxLength={2000}
          />
        </View>

        <View className="py-4">
          <Text className="text-lg font-semibold text-gray-900 mb-2">
            Photos ({photos.length}/5)
          </Text>
          <PhotoSelector
            photos={photos}
            onAddPhotos={handleAddPhoto}
            onRemovePhoto={handleRemovePhoto}
            maxPhotos={5}
          />
        </View>

        <View className="py-4">
          <Text className="text-lg font-semibold text-gray-900 mb-2">
            Location
          </Text>
          <LocationSelector
            location={location}
            onLocationChange={setLocation}
          />
        </View>

        <View className="py-4">
          <Text className="text-lg font-semibold text-gray-900 mb-2">Tags</Text>
          <TagInput
            tags={tags}
            onTagsChange={setTags}
            placeholder="Add tags..."
          />
        </View>

        <View className="py-8">
          <TouchableOpacity
            onPress={handleSave}
            disabled={isLoading}
            className={`py-4 rounded-lg ${
              isLoading ? 'bg-gray-400' : 'bg-blue-500'
            }`}>
            <Text className="text-white text-center font-semibold text-lg">
              {isLoading
                ? isEdit
                  ? 'Updating...'
                  : 'Saving...'
                : isEdit
                ? 'Update Entry'
                : 'Save Entry'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};
