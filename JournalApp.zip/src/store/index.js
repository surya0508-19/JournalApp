import {configureStore} from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import journalReducer from './slices/journalSlice';
import syncReducer from './slices/syncSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    journal: journalReducer,
    sync: syncReducer,
  },
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: ['persist/PERSIST', 'persist/REHYDRATE'],
      },
    }),
});

export const RootState = store.getState;
export const AppDispatch = store.dispatch;
