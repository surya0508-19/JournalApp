import {createSlice, createAsyncThunk} from '@reduxjs/toolkit';
import {syncService} from '../../services/syncService';

const initialState = {
  pendingEntries: [],
  isSyncing: false,
  lastSyncAttempt: null,
  syncError: null,
};

// Async thunks
export const syncPendingEntries = createAsyncThunk(
  'sync/syncPendingEntries',
  async (_, {rejectWithValue, getState}) => {
    try {
      const state = getState();
      const pendingEntries = state.sync.pendingEntries;

      if (pendingEntries.length === 0) {
        return {syncedCount: 0, failedCount: 0};
      }

      const result = await syncService.syncEntries(pendingEntries);
      return result;
    } catch (error) {
      return rejectWithValue(
        error instanceof Error ? error.message : 'Sync failed',
      );
    }
  },
);

export const markEntryAsSynced = createAsyncThunk(
  'sync/markEntryAsSynced',
  async (entryId, {rejectWithValue}) => {
    try {
      await syncService.markEntryAsSynced(entryId);
      return entryId;
    } catch (error) {
      return rejectWithValue(
        error instanceof Error
          ? error.message
          : 'Failed to mark entry as synced',
      );
    }
  },
);

export const checkSyncStatus = createAsyncThunk(
  'sync/checkSyncStatus',
  async (_, {rejectWithValue}) => {
    try {
      const status = await syncService.getSyncStatus();
      return status;
    } catch (error) {
      return rejectWithValue(
        error instanceof Error ? error.message : 'Failed to check sync status',
      );
    }
  },
);

const syncSlice = createSlice({
  name: 'sync',
  initialState,
  reducers: {
    clearSyncError: state => {
      state.syncError = null;
    },
    addPendingEntry: (state, action) => {
      const existingIndex = state.pendingEntries.findIndex(
        entry => entry.id === action.payload.id,
      );
      if (existingIndex === -1) {
        state.pendingEntries.push(action.payload);
      } else {
        state.pendingEntries[existingIndex] = action.payload;
      }
    },
    removePendingEntry: (state, action) => {
      state.pendingEntries = state.pendingEntries.filter(
        entry => entry.id !== action.payload,
      );
    },
    clearPendingEntries: state => {
      state.pendingEntries = [];
    },
    setLastSyncAttempt: (state, action) => {
      state.lastSyncAttempt = action.payload;
    },
  },
  extraReducers: builder => {
    builder
      // Sync pending entries
      .addCase(syncPendingEntries.pending, state => {
        state.isSyncing = true;
        state.syncError = null;
      })
      .addCase(syncPendingEntries.fulfilled, (state, action) => {
        state.isSyncing = false;
        state.syncError = null;
        state.lastSyncAttempt = new Date().toISOString();

        // Remove successfully synced entries from pending list
        if (action.payload.syncedCount > 0) {
          // This would be handled by the journal slice updating the entries
          state.pendingEntries = [];
        }
      })
      .addCase(syncPendingEntries.rejected, (state, action) => {
        state.isSyncing = false;
        state.syncError = action.payload;
        state.lastSyncAttempt = new Date().toISOString();
      })
      // Mark entry as synced
      .addCase(markEntryAsSynced.fulfilled, (state, action) => {
        state.pendingEntries = state.pendingEntries.filter(
          entry => entry.id !== action.payload,
        );
      })
      // Check sync status
      .addCase(checkSyncStatus.fulfilled, (state, action) => {
        state.pendingEntries = action.payload.pendingEntries || [];
        state.lastSyncAttempt = action.payload.lastSyncAttempt;
      });
  },
});

export const {
  clearSyncError,
  addPendingEntry,
  removePendingEntry,
  clearPendingEntries,
  setLastSyncAttempt,
} = syncSlice.actions;
export default syncSlice.reducer;
