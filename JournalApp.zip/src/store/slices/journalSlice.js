import {createSlice, createAsyncThunk} from '@reduxjs/toolkit';
import {journalService} from '../../services/journalService';

const initialState = {
  entries: [],
  isLoading: false,
  error: null,
  lastSyncTime: null,
  isOffline: false,
};

// Async thunks
export const fetchJournalEntries = createAsyncThunk(
  'journal/fetchEntries',
  async (_, {rejectWithValue}) => {
    try {
      const entries = await journalService.getAllEntries();
      return entries;
    } catch (error) {
      return rejectWithValue(
        error instanceof Error ? error.message : 'Failed to fetch entries',
      );
    }
  },
);

export const createJournalEntry = createAsyncThunk(
  'journal/createEntry',
  async (entry, {rejectWithValue}) => {
    try {
      const newEntry = await journalService.createEntry(entry);
      return newEntry;
    } catch (error) {
      return rejectWithValue(
        error instanceof Error ? error.message : 'Failed to create entry',
      );
    }
  },
);

export const updateJournalEntry = createAsyncThunk(
  'journal/updateEntry',
  async ({id, updates}, {rejectWithValue}) => {
    try {
      const updatedEntry = await journalService.updateEntry(id, updates);
      return updatedEntry;
    } catch (error) {
      return rejectWithValue(
        error instanceof Error ? error.message : 'Failed to update entry',
      );
    }
  },
);

export const deleteJournalEntry = createAsyncThunk(
  'journal/deleteEntry',
  async (id, {rejectWithValue}) => {
    try {
      await journalService.deleteEntry(id);
      return id;
    } catch (error) {
      return rejectWithValue(
        error instanceof Error ? error.message : 'Failed to delete entry',
      );
    }
  },
);

export const searchJournalEntries = createAsyncThunk(
  'journal/searchEntries',
  async (filters, {rejectWithValue}) => {
    try {
      const entries = await journalService.searchEntries(filters);
      return entries;
    } catch (error) {
      return rejectWithValue(
        error instanceof Error ? error.message : 'Failed to search entries',
      );
    }
  },
);

const journalSlice = createSlice({
  name: 'journal',
  initialState,
  reducers: {
    clearError: state => {
      state.error = null;
    },
    setOfflineStatus: (state, action) => {
      state.isOffline = action.payload;
    },
    setLastSyncTime: (state, action) => {
      state.lastSyncTime = action.payload;
    },
    addEntry: (state, action) => {
      state.entries.unshift(action.payload);
    },
    updateEntry: (state, action) => {
      const index = state.entries.findIndex(
        entry => entry.id === action.payload.id,
      );
      if (index !== -1) {
        state.entries[index] = action.payload;
      }
    },
    removeEntry: (state, action) => {
      state.entries = state.entries.filter(
        entry => entry.id !== action.payload,
      );
    },
  },
  extraReducers: builder => {
    builder
      // Fetch entries
      .addCase(fetchJournalEntries.pending, state => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchJournalEntries.fulfilled, (state, action) => {
        state.isLoading = false;
        state.entries = action.payload;
        state.error = null;
      })
      .addCase(fetchJournalEntries.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Create entry
      .addCase(createJournalEntry.pending, state => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(createJournalEntry.fulfilled, (state, action) => {
        state.isLoading = false;
        state.entries.unshift(action.payload);
        state.error = null;
      })
      .addCase(createJournalEntry.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Update entry
      .addCase(updateJournalEntry.pending, state => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(updateJournalEntry.fulfilled, (state, action) => {
        state.isLoading = false;
        const index = state.entries.findIndex(
          entry => entry.id === action.payload.id,
        );
        if (index !== -1) {
          state.entries[index] = action.payload;
        }
        state.error = null;
      })
      .addCase(updateJournalEntry.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Delete entry
      .addCase(deleteJournalEntry.pending, state => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(deleteJournalEntry.fulfilled, (state, action) => {
        state.isLoading = false;
        state.entries = state.entries.filter(
          entry => entry.id !== action.payload,
        );
        state.error = null;
      })
      .addCase(deleteJournalEntry.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Search entries
      .addCase(searchJournalEntries.pending, state => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(searchJournalEntries.fulfilled, (state, action) => {
        state.isLoading = false;
        state.entries = action.payload;
        state.error = null;
      })
      .addCase(searchJournalEntries.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      });
  },
});

export const {
  clearError,
  setOfflineStatus,
  setLastSyncTime,
  addEntry,
  updateEntry,
  removeEntry,
} = journalSlice.actions;
export default journalSlice.reducer;
