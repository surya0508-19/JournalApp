import SQLite from 'react-native-sqlite-storage';

// Enable promise-based API
SQLite.enablePromise(true);

const DATABASE_NAME = 'JournalDB.db';
const DATABASE_VERSION = '1.0';
const DATABASE_DISPLAYNAME = 'Journal Database';
const DATABASE_SIZE = 200000;

class DatabaseService {
  constructor() {
    this.db = null;
  }

  async initializeDatabase() {
    try {
      this.db = await SQLite.openDatabase({
        name: DATABASE_NAME,
        version: DATABASE_VERSION,
        displayName: DATABASE_DISPLAYNAME,
        size: DATABASE_SIZE,
        location: 'default',
      });

      await this.createTables();
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Database initialization failed:', error);
      throw error;
    }
  }

  async createTables() {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const createJournalEntriesTable = `
      CREATE TABLE IF NOT EXISTS journal_entries (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        date TEXT NOT NULL,
        location_latitude REAL,
        location_longitude REAL,
        location_address TEXT,
        location_city TEXT,
        location_country TEXT,
        tags TEXT,
        is_synced INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        user_id TEXT NOT NULL
      )
    `;

    const createPhotosTable = `
      CREATE TABLE IF NOT EXISTS photos (
        id TEXT PRIMARY KEY,
        entry_id TEXT NOT NULL,
        uri TEXT NOT NULL,
        type TEXT NOT NULL,
        name TEXT NOT NULL,
        size INTEGER NOT NULL,
        width INTEGER,
        height INTEGER,
        created_at TEXT NOT NULL,
        FOREIGN KEY (entry_id) REFERENCES journal_entries (id) ON DELETE CASCADE
      )
    `;

    const createIndexes = [
      'CREATE INDEX IF NOT EXISTS idx_journal_entries_date ON journal_entries(date)',
      'CREATE INDEX IF NOT EXISTS idx_journal_entries_user_id ON journal_entries(user_id)',
      'CREATE INDEX IF NOT EXISTS idx_journal_entries_is_synced ON journal_entries(is_synced)',
      'CREATE INDEX IF NOT EXISTS idx_photos_entry_id ON photos(entry_id)',
    ];

    try {
      await this.db.executeSql(createJournalEntriesTable);
      await this.db.executeSql(createPhotosTable);

      for (const indexQuery of createIndexes) {
        await this.db.executeSql(indexQuery);
      }
    } catch (error) {
      console.error('Error creating tables:', error);
      throw error;
    }
  }

  async createJournalEntry(entry) {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const id = this.generateId();
    const now = new Date().toISOString();

    const newEntry = {
      ...entry,
      id,
      createdAt: now,
      updatedAt: now,
      isSynced: false,
    };

    try {
      await this.db.transaction(async tx => {
        // Insert journal entry
        const insertEntryQuery = `
          INSERT INTO journal_entries (
            id, title, description, date, location_latitude, location_longitude,
            location_address, location_city, location_country, tags, is_synced,
            created_at, updated_at, user_id
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        const entryValues = [
          newEntry.id,
          newEntry.title,
          newEntry.description,
          newEntry.date,
          newEntry.location?.latitude || null,
          newEntry.location?.longitude || null,
          newEntry.location?.address || null,
          newEntry.location?.city || null,
          newEntry.location?.country || null,
          JSON.stringify(newEntry.tags),
          newEntry.isSynced ? 1 : 0,
          newEntry.createdAt,
          newEntry.updatedAt,
          newEntry.userId,
        ];

        await tx.executeSql(insertEntryQuery, entryValues);

        // Insert photos
        for (const photo of newEntry.photos) {
          const insertPhotoQuery = `
            INSERT INTO photos (
              id, entry_id, uri, type, name, size, width, height, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          `;

          const photoValues = [
            photo.id,
            newEntry.id,
            photo.uri,
            photo.type,
            photo.name,
            photo.size,
            photo.width || null,
            photo.height || null,
            now,
          ];

          await tx.executeSql(insertPhotoQuery, photoValues);
        }
      });

      return newEntry;
    } catch (error) {
      console.error('Error creating journal entry:', error);
      throw error;
    }
  }

  async getAllJournalEntries(userId) {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const [results] = await this.db.executeSql(
        'SELECT * FROM journal_entries WHERE user_id = ? ORDER BY date DESC',
        [userId],
      );

      const entries = [];

      for (let i = 0; i < results.rows.length; i++) {
        const row = results.rows.item(i);
        const photos = await this.getPhotosForEntry(row.id);

        const entry = {
          id: row.id,
          title: row.title,
          description: row.description,
          date: row.date,
          location:
            row.location_latitude && row.location_longitude
              ? {
                  latitude: row.location_latitude,
                  longitude: row.location_longitude,
                  address: row.location_address,
                  city: row.location_city,
                  country: row.location_country,
                }
              : undefined,
          tags: JSON.parse(row.tags || '[]'),
          isSynced: !!row.is_synced,
          createdAt: row.created_at,
          updatedAt: row.updated_at,
          userId: row.user_id,
          photos,
        };

        entries.push(entry);
      }

      return entries;
    } catch (error) {
      console.error('Error fetching journal entries:', error);
      throw error;
    }
  }

  async getJournalEntryById(id) {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const [results] = await this.db.executeSql(
        'SELECT * FROM journal_entries WHERE id = ?',
        [id],
      );

      if (results.rows.length === 0) {
        return null;
      }

      const row = results.rows.item(0);
      const photos = await this.getPhotosForEntry(id);

      return {
        id: row.id,
        title: row.title,
        description: row.description,
        date: row.date,
        location:
          row.location_latitude && row.location_longitude
            ? {
                latitude: row.location_latitude,
                longitude: row.location_longitude,
                address: row.location_address,
                city: row.location_city,
                country: row.location_country,
              }
            : undefined,
        tags: JSON.parse(row.tags || '[]'),
        isSynced: !!row.is_synced,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
        userId: row.user_id,
        photos,
      };
    } catch (error) {
      console.error('Error fetching journal entry:', error);
      throw error;
    }
  }

  async updateJournalEntry(id, updates) {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const existingEntry = await this.getJournalEntryById(id);
      if (!existingEntry) {
        throw new Error('Journal entry not found');
      }

      const updatedEntry = {
        ...existingEntry,
        ...updates,
        updatedAt: new Date().toISOString(),
      };

      await this.db.transaction(async tx => {
        // Update journal entry
        const updateEntryQuery = `
          UPDATE journal_entries SET
            title = ?, description = ?, date = ?, location_latitude = ?,
            location_longitude = ?, location_address = ?, location_city = ?,
            location_country = ?, tags = ?, is_synced = ?, updated_at = ?
          WHERE id = ?
        `;

        const entryValues = [
          updatedEntry.title,
          updatedEntry.description,
          updatedEntry.date || existingEntry.date, // Preserve original date if not provided
          updatedEntry.location?.latitude || null,
          updatedEntry.location?.longitude || null,
          updatedEntry.location?.address || null,
          updatedEntry.location?.city || null,
          updatedEntry.location?.country || null,
          JSON.stringify(updatedEntry.tags),
          updatedEntry.isSynced ? 1 : 0,
          updatedEntry.updatedAt,
          id,
        ];

        await tx.executeSql(updateEntryQuery, entryValues);

        // Update photos if provided
        if (updates.photos) {
          // Delete existing photos
          await tx.executeSql('DELETE FROM photos WHERE entry_id = ?', [id]);

          // Insert new photos
          for (const photo of updatedEntry.photos) {
            const insertPhotoQuery = `
              INSERT INTO photos (
                id, entry_id, uri, type, name, size, width, height, created_at
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `;

            const photoValues = [
              photo.id,
              id,
              photo.uri,
              photo.type,
              photo.name,
              photo.size,
              photo.width || null,
              photo.height || null,
              new Date().toISOString(),
            ];

            await tx.executeSql(insertPhotoQuery, photoValues);
          }
        }
      });

      return updatedEntry;
    } catch (error) {
      console.error('Error updating journal entry:', error);
      throw error;
    }
  }

  async deleteJournalEntry(id) {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      await this.db.transaction(async tx => {
        // Delete photos first (due to foreign key constraint)
        await tx.executeSql('DELETE FROM photos WHERE entry_id = ?', [id]);

        // Delete journal entry
        await tx.executeSql('DELETE FROM journal_entries WHERE id = ?', [id]);
      });
    } catch (error) {
      console.error('Error deleting journal entry:', error);
      throw error;
    }
  }

  async getUnsyncedEntries() {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const [results] = await this.db.executeSql(
        'SELECT * FROM journal_entries WHERE is_synced = 0 ORDER BY created_at ASC',
      );

      const entries = [];

      for (let i = 0; i < results.rows.length; i++) {
        const row = results.rows.item(i);
        const photos = await this.getPhotosForEntry(row.id);

        const entry = {
          id: row.id,
          title: row.title,
          description: row.description,
          date: row.date,
          location:
            row.location_latitude && row.location_longitude
              ? {
                  latitude: row.location_latitude,
                  longitude: row.location_longitude,
                  address: row.location_address,
                  city: row.location_city,
                  country: row.location_country,
                }
              : undefined,
          tags: JSON.parse(row.tags || '[]'),
          isSynced: !!row.is_synced,
          createdAt: row.created_at,
          updatedAt: row.updated_at,
          userId: row.user_id,
          photos,
        };

        entries.push(entry);
      }

      return entries;
    } catch (error) {
      console.error('Error fetching unsynced entries:', error);
      throw error;
    }
  }

  async markEntryAsSynced(id) {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      await this.db.executeSql(
        'UPDATE journal_entries SET is_synced = 1 WHERE id = ?',
        [id],
      );
    } catch (error) {
      console.error('Error marking entry as synced:', error);
      throw error;
    }
  }

  async getPhotosForEntry(entryId) {
    if (!this.db) {
      return [];
    }

    try {
      const [results] = await this.db.executeSql(
        'SELECT * FROM photos WHERE entry_id = ? ORDER BY created_at ASC',
        [entryId],
      );

      const photos = [];

      for (let i = 0; i < results.rows.length; i++) {
        const row = results.rows.item(i);
        photos.push({
          id: row.id,
          uri: row.uri,
          type: row.type,
          name: row.name,
          size: row.size,
          width: row.width,
          height: row.height,
        });
      }

      return photos;
    } catch (error) {
      console.error('Error fetching photos for entry:', error);
      return [];
    }
  }

  generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  async closeDatabase() {
    if (this.db) {
      await this.db.close();
      this.db = null;
    }
  }
}

export const databaseService = new DatabaseService();
