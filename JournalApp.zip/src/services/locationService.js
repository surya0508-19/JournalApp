// import Geolocation from '@react-native-community/geolocation';
import Geolocation from 'react-native-geolocation-service';
import {Platform, PermissionsAndroid} from 'react-native';

class LocationService {
  constructor() {
    this.defaultOptions = {
      enableHighAccuracy: true,
      timeout: 15000,
      maximumAge: 10000,
    };
  }

  async getCurrentLocation(options) {
    return new Promise(async (resolve, reject) => {
      // Check permission first
      const hasPermission = await this.checkLocationPermission();
      if (!hasPermission) {
        reject(new Error('Location permission was not granted.'));
        return;
      }

      const opts = {...this.defaultOptions, ...options};

      console.log('optsddddd', opts);

      Geolocation.getCurrentPosition(
        async position => {
          try {
            console.log('positionddddd', position);
            const location = {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
            };

            // Try to get address from coordinates
            try {
              const address = await this.reverseGeocode(
                position.coords.latitude,
                position.coords.longitude,
              );
              location.address = address.address;
              location.city = address.city;
              location.country = address.country;
            } catch (error) {
              console.warn('Failed to get address from coordinates:', error);
            }

            resolve(location);
          } catch (error) {
            reject(error);
          }
        },
        error => {
          console.error('Geolocation error:', error);
          let errorMessage = 'Failed to get location';

          if (error.code === 1) {
            errorMessage = 'Location permission was not granted.';
          } else if (error.code === 2) {
            errorMessage = 'Location is currently unavailable.';
          } else if (error.code === 3) {
            errorMessage = 'Location request timed out.';
          }

          reject(new Error(errorMessage));
        },
        opts,
      );
    });
  }

  async watchPosition(onLocationUpdate, onError, options) {
    const opts = {...this.defaultOptions, ...options};

    return new Promise((resolve, reject) => {
      const watchId = Geolocation.watchPosition(
        position => {
          const location = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          };
          onLocationUpdate(location);
        },
        error => {
          console.error('Watch position error:', error);
          onError(new Error(`Location error: ${error.message}`));
        },
        opts,
      );

      resolve(watchId);
    });
  }

  clearWatch(watchId) {
    Geolocation.clearWatch(watchId);
  }

  async requestLocationPermission() {
    if (Platform.OS === 'android') {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: 'Location Permission',
          message: 'We need access to your location to track movement',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      );
      return granted === PermissionsAndroid.RESULTS.GRANTED;
    } else {
      // iOS - use the old method for now
      return new Promise(resolve => {
        Geolocation.requestAuthorization(
          () => {
            console.log('Location permission granted');
            resolve(true);
          },
          error => {
            console.error('Location permission denied:', error);
            resolve(false);
          },
        );
      });
    }
  }

  async checkLocationPermission() {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.check(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        );
        console.log('grantedddddsd', granted);
        return granted;
      } catch (err) {
        console.warn('Permission check error:', err);
        return false;
      }
    } else {
      // iOS - use the old method
      return new Promise(resolve => {
        Geolocation.getCurrentPosition(
          () => resolve(true),
          error => {
            if (error.code === 1) {
              // PERMISSION_DENIED
              resolve(false);
            } else {
              resolve(true); // Permission granted but other error
            }
          },
          {timeout: 1000, maximumAge: 0},
        );
      });
    }
  }

  async reverseGeocode(latitude, longitude) {
    // This is a mock implementation
    // In a real app, you would use a geocoding service like Google Maps API
    // or a free service like OpenStreetMap Nominatim

    const GOOGLE_API_KEY = 'AIzaSyC4NMhnSz5sYMYwRXJ4qvDNFPqHasqa1YQ';
    try {
      // const response = await fetch(
      //   `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${GOOGLE_API_KEY}`,
      // );
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`,
      );
      if (!response.ok) {
        throw new Error('Reverse geocoding failed');
      }

      const data = await response.json();
      console.log('data', data);

      return {
        address: data.display_name || '',
        city:
          data.address?.city ||
          data.address?.town ||
          data.address?.village ||
          '',
        country: data.address?.country || '',
      };
    } catch (error) {
      console.error('Reverse geocoding error:', error);
      throw error;
    }
  }

  calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Radius of the Earth in kilometers
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.deg2rad(lat1)) *
        Math.cos(this.deg2rad(lat2)) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distance in kilometers
    return distance;
  }

  deg2rad(deg) {
    return deg * (Math.PI / 180);
  }

  formatDistance(distance) {
    if (distance < 1) {
      return `${Math.round(distance * 1000)}m`;
    } else if (distance < 10) {
      return `${distance.toFixed(1)}km`;
    } else {
      return `${Math.round(distance)}km`;
    }
  }

  formatLocation(location) {
    if (location.address) {
      return location.address;
    } else if (location.city && location.country) {
      return `${location.city}, ${location.country}`;
    } else {
      return `${location.latitude.toFixed(4)}, ${location.longitude.toFixed(
        4,
      )}`;
    }
  }
}

export const locationService = new LocationService();
