import {launchImageLibrary, launchCamera} from 'react-native-image-picker';

class PhotoService {
  constructor() {
    this.defaultOptions = {
      mediaType: 'photo',
      quality: 0.8,
      maxWidth: 1024,
      maxHeight: 1024,
      includeBase64: false,
    };
  }

  async selectFromGallery(options) {
    return new Promise((resolve, reject) => {
      const opts = {...this.defaultOptions, ...options};

      launchImageLibrary(opts, response => {
        if (response.didCancel) {
          resolve([]);
          return;
        }

        if (response.errorMessage) {
          reject(new Error(response.errorMessage));
          return;
        }

        if (!response.assets || response.assets.length === 0) {
          resolve([]);
          return;
        }

        const photos = response.assets.map((asset, index) => ({
          id: `photo_${Date.now()}_${index}`,
          uri: asset.uri || '',
          type: asset.type || 'image/jpeg',
          name: asset.fileName || `photo_${Date.now()}_${index}.jpg`,
          size: asset.fileSize || 0,
          width: asset.width,
          height: asset.height,
        }));

        resolve(photos);
      });
    });
  }

  async takePhoto(options) {
    return new Promise((resolve, reject) => {
      const opts = {...this.defaultOptions, ...options};

      launchCamera(opts, response => {
        if (response.didCancel) {
          resolve([]);
          return;
        }

        if (response.errorMessage) {
          reject(new Error(response.errorMessage));
          return;
        }

        if (!response.assets || response.assets.length === 0) {
          resolve([]);
          return;
        }

        const photos = response.assets.map((asset, index) => ({
          id: `photo_${Date.now()}_${index}`,
          uri: asset.uri || '',
          type: asset.type || 'image/jpeg',
          name: asset.fileName || `photo_${Date.now()}_${index}.jpg`,
          size: asset.fileSize || 0,
          width: asset.width,
          height: asset.height,
        }));

        resolve(photos);
      });
    });
  }

  async selectMultipleFromGallery(maxCount = 5, options) {
    return new Promise((resolve, reject) => {
      const opts = {
        ...this.defaultOptions,
        ...options,
        selectionLimit: maxCount,
      };

      launchImageLibrary(opts, response => {
        if (response.didCancel) {
          resolve([]);
          return;
        }

        if (response.errorMessage) {
          reject(new Error(response.errorMessage));
          return;
        }

        if (!response.assets || response.assets.length === 0) {
          resolve([]);
          return;
        }

        const photos = response.assets.map((asset, index) => ({
          id: `photo_${Date.now()}_${index}`,
          uri: asset.uri || '',
          type: asset.type || 'image/jpeg',
          name: asset.fileName || `photo_${Date.now()}_${index}.jpg`,
          size: asset.fileSize || 0,
          width: asset.width,
          height: asset.height,
        }));

        resolve(photos);
      });
    });
  }

  async compressPhoto(photo, quality = 0.8) {
    // This is a simplified compression implementation
    // In a real app, you might want to use a library like react-native-image-resizer
    return {
      ...photo,
      // The actual compression would happen here
      // For now, we'll just return the original photo
    };
  }

  async resizePhoto(photo, maxWidth = 1024, maxHeight = 1024) {
    // This is a simplified resize implementation
    // In a real app, you might want to use a library like react-native-image-resizer
    return {
      ...photo,
      width: maxWidth,
      height: maxHeight,
      // The actual resizing would happen here
    };
  }

  formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  validatePhoto(photo) {
    if (!photo.uri) {
      return {isValid: false, error: 'Photo URI is required'};
    }

    if (!photo.type || !photo.type.startsWith('image/')) {
      return {isValid: false, error: 'Invalid photo type'};
    }

    if (photo.size > 10 * 1024 * 1024) {
      // 10MB limit
      return {isValid: false, error: 'Photo size exceeds 10MB limit'};
    }

    return {isValid: true};
  }

  async getPhotoInfo(uri) {
    // This is a simplified implementation
    // In a real app, you might want to use a library to get actual image dimensions
    return new Promise(resolve => {
      // Mock implementation - in reality you'd use Image.getSize or similar
      resolve({
        width: 1024,
        height: 768,
        size: 0,
      });
    });
  }

  generatePhotoId() {
    return `photo_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  async copyPhotoToAppDirectory(photo) {
    // This is a simplified implementation
    // In a real app, you might want to copy the photo to your app's directory
    // and return the new URI
    return photo.uri;
  }

  async deletePhoto(uri) {
    // This is a simplified implementation
    // In a real app, you might want to delete the photo file from storage
    console.log(`Deleting photo: ${uri}`);
  }

  async getPhotosFromEntry(entryId) {
    // This would typically fetch photos from your database
    // For now, returning empty array
    return [];
  }

  async savePhotoToEntry(entryId, photo) {
    // This would typically save the photo to your database
    console.log(`Saving photo to entry ${entryId}:`, photo);
  }

  async removePhotoFromEntry(entryId, photoId) {
    // This would typically remove the photo from your database
    console.log(`Removing photo ${photoId} from entry ${entryId}`);
  }
}

export const photoService = new PhotoService();
