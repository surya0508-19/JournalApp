import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {authService} from './authService';

const SYNC_STORAGE_KEY = '@journal_sync_status';
const API_BASE_URL = 'https://your-api-endpoint.com/api'; // Replace with your actual API endpoint

class SyncService {
  constructor() {
    this.isOnline = true;
    this.syncInProgress = false;
    this.checkNetworkStatus();
  }

  async checkNetworkStatus() {
    try {
      // Simple network check
      const response = await fetch('https://www.google.com', {
        method: 'HEAD',
        mode: 'no-cors',
        cache: 'no-cache',
      });
      this.isOnline = true;
    } catch (error) {
      this.isOnline = false;
    }
  }

  async syncEntries(entries) {
    if (this.syncInProgress) {
      throw new Error('Sync already in progress');
    }

    this.syncInProgress = true;
    const result = {
      syncedCount: 0,
      failedCount: 0,
      errors: [],
    };

    try {
      await this.checkNetworkStatus();

      if (!this.isOnline) {
        throw new Error('No internet connection');
      }

      const user = await authService.getCurrentUser();
      if (!user) {
        throw new Error('User not authenticated');
      }

      // Get auth token
      const token = await authService.refreshToken();
      if (!token) {
        throw new Error('Failed to get authentication token');
      }

      // Create axios instance with auth headers
      const apiClient = axios.create({
        baseURL: API_BASE_URL,
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        timeout: 30000,
      });

      // Sync each entry
      for (const entry of entries) {
        try {
          await this.syncSingleEntry(apiClient, entry);
          result.syncedCount++;
        } catch (error) {
          result.failedCount++;
          result.errors.push(
            `Failed to sync entry "${entry.title}": ${
              error instanceof Error ? error.message : 'Unknown error'
            }`,
          );
        }
      }

      // Update sync status
      await this.updateSyncStatus({
        lastSyncTime: new Date().toISOString(),
        pendingEntries: [],
        isOnline: this.isOnline,
      });
    } catch (error) {
      console.error('Sync error:', error);
      throw error;
    } finally {
      this.syncInProgress = false;
    }

    return result;
  }

  async syncSingleEntry(apiClient, entry) {
    try {
      // Check if entry exists on server
      const existingEntry = await this.getEntryFromServer(apiClient, entry.id);

      if (existingEntry) {
        // Update existing entry
        await apiClient.put(`/entries/${entry.id}`, {
          title: entry.title,
          description: entry.description,
          date: entry.date,
          location: entry.location,
          tags: entry.tags,
          photos: entry.photos,
          updatedAt: entry.updatedAt,
        });
      } else {
        // Create new entry
        await apiClient.post('/entries', {
          id: entry.id,
          title: entry.title,
          description: entry.description,
          date: entry.date,
          location: entry.location,
          tags: entry.tags,
          photos: entry.photos,
          createdAt: entry.createdAt,
          updatedAt: entry.updatedAt,
        });
      }

      // Mark as synced in local database
      const {journalService} = await import('./journalService');
      await journalService.markEntryAsSynced(entry.id);
    } catch (error) {
      console.error(`Error syncing entry ${entry.id}:`, error);
      throw error;
    }
  }

  async getEntryFromServer(apiClient, entryId) {
    try {
      const response = await apiClient.get(`/entries/${entryId}`);
      return response.data;
    } catch (error) {
      if (error.response?.status === 404) {
        return null; // Entry doesn't exist on server
      }
      throw error;
    }
  }

  async getSyncStatus() {
    try {
      const stored = await AsyncStorage.getItem(SYNC_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (error) {
      console.error('Error getting sync status:', error);
    }

    return {
      lastSyncTime: null,
      pendingEntries: [],
      isOnline: this.isOnline,
    };
  }

  async updateSyncStatus(status) {
    try {
      const currentStatus = await this.getSyncStatus();
      const updatedStatus = {...currentStatus, ...status};
      await AsyncStorage.setItem(
        SYNC_STORAGE_KEY,
        JSON.stringify(updatedStatus),
      );
    } catch (error) {
      console.error('Error updating sync status:', error);
    }
  }

  async markEntryAsSynced(entryId) {
    try {
      const {journalService} = await import('./journalService');
      await journalService.markEntryAsSynced(entryId);
    } catch (error) {
      console.error('Error marking entry as synced:', error);
      throw error;
    }
  }

  async getPendingEntries() {
    try {
      const {journalService} = await import('./journalService');
      return await journalService.getUnsyncedEntries();
    } catch (error) {
      console.error('Error getting pending entries:', error);
      return [];
    }
  }

  async clearSyncStatus() {
    try {
      await AsyncStorage.removeItem(SYNC_STORAGE_KEY);
    } catch (error) {
      console.error('Error clearing sync status:', error);
    }
  }

  async forceSync() {
    try {
      const pendingEntries = await this.getPendingEntries();
      if (pendingEntries.length === 0) {
        return {syncedCount: 0, failedCount: 0, errors: []};
      }

      return await this.syncEntries(pendingEntries);
    } catch (error) {
      console.error('Force sync error:', error);
      throw error;
    }
  }

  async downloadEntriesFromServer() {
    try {
      await this.checkNetworkStatus();

      if (!this.isOnline) {
        throw new Error('No internet connection');
      }

      const user = await authService.getCurrentUser();
      if (!user) {
        throw new Error('User not authenticated');
      }

      const token = await authService.refreshToken();
      if (!token) {
        throw new Error('Failed to get authentication token');
      }

      const apiClient = axios.create({
        baseURL: API_BASE_URL,
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        timeout: 30000,
      });

      const response = await apiClient.get('/entries');
      return response.data;
    } catch (error) {
      console.error('Error downloading entries from server:', error);
      throw error;
    }
  }

  async uploadPhotoToServer(photoUri, entryId) {
    try {
      const user = await authService.getCurrentUser();
      if (!user) {
        throw new Error('User not authenticated');
      }

      const token = await authService.refreshToken();
      if (!token) {
        throw new Error('Failed to get authentication token');
      }

      const formData = new FormData();
      formData.append('photo', {
        uri: photoUri,
        type: 'image/jpeg',
        name: `photo_${Date.now()}.jpg`,
      });
      formData.append('entryId', entryId);

      const response = await axios.post(
        `${API_BASE_URL}/upload-photo`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data',
          },
          timeout: 60000,
        },
      );

      return response.data.photoUrl;
    } catch (error) {
      console.error('Error uploading photo to server:', error);
      throw error;
    }
  }

  isSyncInProgress() {
    return this.syncInProgress;
  }

  getOnlineStatus() {
    return this.isOnline;
  }
}

export const syncService = new SyncService();
