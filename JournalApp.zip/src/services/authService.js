import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  GoogleSignin,
  statusCodes,
} from '@react-native-google-signin/google-signin';

const USER_STORAGE_KEY = '@journal_user';
const TOKEN_STORAGE_KEY = '@journal_token';

class AuthService {
  constructor() {
    this.currentUser = null;
    this.initializeGoogleSignin();
  }

  async initializeGoogleSignin() {
    try {
      await GoogleSignin.configure({
        webClientId:
          '310135870071-of1jt9uocdbjb34npk4ijv2iibvnr69n.apps.googleusercontent.com',
        offlineAccess: true,
        hostedDomain: '',
        forceCodeForRefreshToken: true,
        scopes: [
          'https://www.googleapis.com/auth/userinfo.profile',
          'https://www.googleapis.com/auth/userinfo.email',
        ],
      });
    } catch (error) {
      console.error('Failed to initialize Google Signin:', error);
    }
  }

  async signInWithGoogle() {
    try {
      // Check if device supports Google Play Services
      await GoogleSignin.hasPlayServices();

      // Sign in
      const userInfos = await GoogleSignin.signIn();

      // Debug logging to understand the response structure
      console.log(
        'Google Sign-in response:',
        JSON.stringify(userInfos, null, 2),
      );
      console.log('userDatasss', userInfo);
      let userInfo = userInfos.data;
      // Handle different response formats
      let userData = null;

      if (userInfo.user) {
        // Standard format
        userData = userInfo.user;
      } else if (userInfo.data) {
        // Alternative format
        userData = userInfo.data;
      } else if (userInfo) {
        // Direct user data
        userData = userInfo;
      }

      if (!userData) {
        console.error('No user data found in response:', userInfo);
        throw new Error('No user information received from Google');
      }

      // Validate required fields
      if (!userData.id && !userData.sub) {
        console.error('Missing user ID in response:', userData);
        throw new Error('User ID not found in Google response');
      }

      const user = {
        id: userData.id || userData.sub,
        email: userData.email || '',
        name: userData.name || userData.given_name || '',
        photo: userData.photo || userData.picture || undefined,
        provider: 'google',
      };

      // Store user data securely
      await this.storeUserData(user);
      this.currentUser = user;

      return user;
    } catch (error) {
      console.error('Google Sign-in error:', error);

      if (error.code === statusCodes.SIGN_IN_CANCELLED) {
        throw new Error('Sign in was cancelled');
      } else if (error.code === statusCodes.IN_PROGRESS) {
        throw new Error('Sign in is already in progress');
      } else if (error.code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) {
        throw new Error('Google Play Services not available');
      } else {
        throw new Error(`Sign in failed: ${error.message}`);
      }
    }
  }

  async signOut() {
    try {
      // Sign out from Google
      await GoogleSignin.signOut();

      // Clear stored data
      await this.clearStoredData();
      this.currentUser = null;
    } catch (error) {
      console.error('Sign out error:', error);
      throw new Error('Failed to sign out');
    }
  }

  async getCurrentUser() {
    try {
      // Check if we have a cached user
      if (this.currentUser) {
        return this.currentUser;
      }

      // Try to get user from storage
      const storedUser = await this.getStoredUserData();
      if (storedUser) {
        this.currentUser = storedUser;
        return storedUser;
      }

      // Check if user is signed in with Google
      const isSignedIn = await GoogleSignin.isSignedIn();
      if (isSignedIn) {
        const userInfo = await GoogleSignin.getCurrentUser();
        console.log('Current user info:', JSON.stringify(userInfo, null, 2));

        if (userInfo) {
          // Handle different response formats
          let userData = null;

          if (userInfo.user) {
            userData = userInfo.user;
          } else if (userInfo.data) {
            userData = userInfo.data;
          } else {
            userData = userInfo;
          }

          if (userData && (userData.id || userData.sub)) {
            const user = {
              id: userData.id || userData.sub,
              email: userData.email || '',
              name: userData.name || userData.given_name || '',
              photo: userData.photo || userData.picture || undefined,
              provider: 'google',
            };

            await this.storeUserData(user);
            this.currentUser = user;
            return user;
          }
        }
      }

      return null;
    } catch (error) {
      console.error('Get current user error:', error);
      return null;
    }
  }

  async isAuthenticated() {
    try {
      const user = await this.getCurrentUser();
      return !!user;
    } catch (error) {
      console.error('Authentication check error:', error);
      return false;
    }
  }

  async refreshToken() {
    try {
      const tokens = await GoogleSignin.getTokens();
      return tokens.accessToken;
    } catch (error) {
      console.error('Token refresh error:', error);
      return null;
    }
  }

  async storeUserData(user) {
    try {
      await AsyncStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
    } catch (error) {
      console.error('Failed to store user data:', error);
      throw new Error('Failed to store user data');
    }
  }

  async getStoredUserData() {
    try {
      const userData = await AsyncStorage.getItem(USER_STORAGE_KEY);
      return userData ? JSON.parse(userData) : null;
    } catch (error) {
      console.error('Failed to get stored user data:', error);
      return null;
    }
  }

  async clearStoredData() {
    try {
      await AsyncStorage.multiRemove([USER_STORAGE_KEY, TOKEN_STORAGE_KEY]);
    } catch (error) {
      console.error('Failed to clear stored data:', error);
    }
  }

  async revokeAccess() {
    try {
      await GoogleSignin.revokeAccess();
      await this.clearStoredData();
      this.currentUser = null;
    } catch (error) {
      console.error('Failed to revoke access:', error);
      throw new Error('Failed to revoke access');
    }
  }
}

export const authService = new AuthService();
