import {databaseService} from './databaseService';
import {locationService} from './locationService';
import {authService} from './authService';

class JournalService {
  async getAllEntries() {
    try {
      const user = await authService.getCurrentUser();
      if (!user) {
        throw new Error('User not authenticated');
      }

      return await databaseService.getAllJournalEntries(user.id);
    } catch (error) {
      console.error('Error getting all entries:', error);
      throw error;
    }
  }

  async getEntryById(id) {
    try {
      return await databaseService.getJournalEntryById(id);
    } catch (error) {
      console.error('Error getting entry by ID:', error);
      throw error;
    }
  }

  async createEntry(entryData) {
    try {
      const user = await authService.getCurrentUser();
      if (!user) {
        throw new Error('User not authenticated');
      }

      // Auto-fetch location if not provided
      let location = entryData.location;
      if (!location) {
        try {
          location = await locationService.getCurrentLocation();
        } catch (error) {
          console.warn('Failed to get current location:', error);
          // Continue without location
        }
      }

      const entryWithUser = {
        ...entryData,
        userId: user.id,
        location,
      };

      return await databaseService.createJournalEntry(entryWithUser);
    } catch (error) {
      console.error('Error creating entry:', error);
      throw error;
    }
  }

  async updateEntry(id, updates) {
    try {
      return await databaseService.updateJournalEntry(id, updates);
    } catch (error) {
      console.error('Error updating entry:', error);
      throw error;
    }
  }

  async deleteEntry(id) {
    try {
      await databaseService.deleteJournalEntry(id);
    } catch (error) {
      console.error('Error deleting entry:', error);
      throw error;
    }
  }

  async searchEntries(filters) {
    try {
      const user = await authService.getCurrentUser();
      if (!user) {
        throw new Error('User not authenticated');
      }

      const allEntries = await databaseService.getAllJournalEntries(user.id);
      let filteredEntries = [...allEntries];

      // Filter by keywords
      if (filters.keywords) {
        const keywords = filters.keywords.toLowerCase();
        filteredEntries = filteredEntries.filter(
          entry =>
            entry.title.toLowerCase().includes(keywords) ||
            entry.description.toLowerCase().includes(keywords) ||
            entry.tags.some(tag => tag.toLowerCase().includes(keywords)),
        );
      }

      // Filter by tags
      if (filters.tags && filters.tags.length > 0) {
        filteredEntries = filteredEntries.filter(entry =>
          filters.tags.some(filterTag =>
            entry.tags.some(entryTag =>
              entryTag.toLowerCase().includes(filterTag.toLowerCase()),
            ),
          ),
        );
      }

      // Filter by date range
      if (filters.dateRange) {
        const startDate = new Date(filters.dateRange.start);
        const endDate = new Date(filters.dateRange.end);

        filteredEntries = filteredEntries.filter(entry => {
          const entryDate = new Date(entry.date);
          return entryDate >= startDate && entryDate <= endDate;
        });
      }

      // Filter by location proximity
      if (filters.location) {
        filteredEntries = filteredEntries.filter(entry => {
          if (!entry.location) return false;

          const distance = this.calculateDistance(
            filters.location.latitude,
            filters.location.longitude,
            entry.location.latitude,
            entry.location.longitude,
          );

          return distance <= filters.location.radius;
        });
      }

      return filteredEntries;
    } catch (error) {
      console.error('Error searching entries:', error);
      throw error;
    }
  }

  async getUnsyncedEntries() {
    try {
      return await databaseService.getUnsyncedEntries();
    } catch (error) {
      console.error('Error getting unsynced entries:', error);
      throw error;
    }
  }

  async markEntryAsSynced(id) {
    try {
      await databaseService.markEntryAsSynced(id);
    } catch (error) {
      console.error('Error marking entry as synced:', error);
      throw error;
    }
  }

  async addPhotoToEntry(entryId, photo) {
    try {
      const entry = await this.getEntryById(entryId);
      if (!entry) {
        throw new Error('Entry not found');
      }

      if (entry.photos.length >= 5) {
        throw new Error('Maximum 5 photos allowed per entry');
      }

      const updatedPhotos = [...entry.photos, photo];
      return await this.updateEntry(entryId, {photos: updatedPhotos});
    } catch (error) {
      console.error('Error adding photo to entry:', error);
      throw error;
    }
  }

  async removePhotoFromEntry(entryId, photoId) {
    try {
      const entry = await this.getEntryById(entryId);
      if (!entry) {
        throw new Error('Entry not found');
      }

      const updatedPhotos = entry.photos.filter(photo => photo.id !== photoId);
      return await this.updateEntry(entryId, {photos: updatedPhotos});
    } catch (error) {
      console.error('Error removing photo from entry:', error);
      throw error;
    }
  }

  async reorderPhotos(entryId, photoIds) {
    try {
      const entry = await this.getEntryById(entryId);
      if (!entry) {
        throw new Error('Entry not found');
      }

      const reorderedPhotos = photoIds
        .map(id => entry.photos.find(photo => photo.id === id))
        .filter(photo => photo !== undefined);

      return await this.updateEntry(entryId, {photos: reorderedPhotos});
    } catch (error) {
      console.error('Error reordering photos:', error);
      throw error;
    }
  }

  calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Radius of the Earth in kilometers
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.deg2rad(lat1)) *
        Math.cos(this.deg2rad(lat2)) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distance in kilometers
    return distance;
  }

  deg2rad(deg) {
    return deg * (Math.PI / 180);
  }

  async exportEntries(format = 'json') {
    try {
      const entries = await this.getAllEntries();

      if (format === 'json') {
        return JSON.stringify(entries, null, 2);
      } else {
        // CSV format
        const headers = [
          'Title',
          'Description',
          'Date',
          'Location',
          'Tags',
          'Photos Count',
        ];
        const rows = entries.map(entry => [
          entry.title,
          entry.description,
          entry.date,
          entry.location
            ? `${entry.location.latitude}, ${entry.location.longitude}`
            : '',
          entry.tags.join(', '),
          entry.photos.length.toString(),
        ]);

        const csvContent = [headers, ...rows]
          .map(row => row.map(field => `"${field}"`).join(','))
          .join('\n');

        return csvContent;
      }
    } catch (error) {
      console.error('Error exporting entries:', error);
      throw error;
    }
  }
}

export const journalService = new JournalService();
