// User interface
export const User = {
  id: '',
  email: '',
  name: '',
  photo: '',
  provider: 'google', // 'google' | 'apple'
};

// Location interface
export const Location = {
  latitude: 0,
  longitude: 0,
  address: '',
  city: '',
  country: '',
};

// Photo interface
export const Photo = {
  id: '',
  uri: '',
  type: 'image/jpeg', // 'image/jpeg' | 'image/png'
  name: '',
  size: 0,
  width: 0,
  height: 0,
};

// Journal Entry interface
export const JournalEntry = {
  id: '',
  title: '',
  description: '',
  photos: [],
  date: '', // ISO string
  location: null,
  tags: [],
  isSynced: false,
  createdAt: '',
  updatedAt: '',
  userId: '',
};

// Auth State interface
export const AuthState = {
  user: null,
  isAuthenticated: false,
  isLoading: false,
  error: null,
};

// Journal State interface
export const JournalState = {
  entries: [],
  isLoading: false,
  error: null,
  lastSyncTime: null,
  isOffline: false,
};

// Sync State interface
export const SyncState = {
  pendingEntries: [],
  isSyncing: false,
  lastSyncAttempt: null,
  syncError: null,
};

// Root State interface
export const RootState = {
  auth: AuthState,
  journal: JournalState,
  sync: SyncState,
};

// Search Filters interface
export const SearchFilters = {
  keywords: '',
  tags: [],
  dateRange: {
    start: '',
    end: '',
  },
  location: {
    latitude: 0,
    longitude: 0,
    radius: 0, // in kilometers
  },
};

// Voice Note interface
export const VoiceNote = {
  id: '',
  uri: '',
  duration: 0,
  transcription: '',
  createdAt: '',
};
