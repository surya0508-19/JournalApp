import React from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';

export const JournalEntryCard = ({entry, onPress, onDelete}) => {
  const formatDate = dateString => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const getPreviewText = (text, maxLength = 100) => {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  };

  return (
    <TouchableOpacity
      onPress={onPress}
      className="bg-white rounded-lg p-4 mb-4 shadow-sm border border-gray-200">
      <View className="flex-row justify-between items-start mb-2">
        <Text className="text-lg font-semibold text-gray-900 flex-1 mr-2">
          {entry.title}
        </Text>
        <View className="flex-row items-center">
          <View
            className={`w-2 h-2 rounded-full mr-2 ${
              entry.isSynced ? 'bg-green-500' : 'bg-yellow-500'
            }`}
          />
          <Text className="text-sm text-gray-500">
            {formatDate(entry.date)}
          </Text>
        </View>
      </View>

      <Text className="text-gray-600 mb-3 leading-5">
        {getPreviewText(entry.description)}
      </Text>

      {entry.photos && entry.photos.length > 0 && (
        <View className="mb-3">
          <Image
            source={{uri: entry.photos[0].uri}}
            className="w-full h-32 rounded-lg"
            resizeMode="cover"
          />
          {entry.photos.length > 1 && (
            <View className="absolute top-2 right-2 bg-black bg-opacity-50 px-2 py-1 rounded">
              <Text className="text-white text-xs">
                +{entry.photos.length - 1}
              </Text>
            </View>
          )}
        </View>
      )}

      {entry.tags && entry.tags.length > 0 && (
        <View className="flex-row flex-wrap mb-2">
          {entry.tags.slice(0, 3).map((tag, index) => (
            <View
              key={index}
              className="bg-blue-100 px-2 py-1 rounded-full mr-2 mb-1">
              <Text className="text-blue-800 text-xs">#{tag}</Text>
            </View>
          ))}
          {entry.tags.length > 3 && (
            <View className="bg-gray-100 px-2 py-1 rounded-full">
              <Text className="text-gray-600 text-xs">
                +{entry.tags.length - 3}
              </Text>
            </View>
          )}
        </View>
      )}

      {entry.location && (
        <View className="flex-row items-center">
          <Text className="text-sm text-gray-500 mr-1">📍</Text>
          <Text className="text-sm text-gray-500">
            {entry.location.city || entry.location.address || 'Location added'}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );
};
