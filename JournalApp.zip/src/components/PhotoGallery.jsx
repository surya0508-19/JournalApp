import React, {useState} from 'react';
import {
  View,
  Image,
  TouchableOpacity,
  Modal,
  ScrollView,
  Text,
} from 'react-native';

export const PhotoGallery = ({photos}) => {
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);

  const openModal = photo => {
    setSelectedPhoto(photo);
    setModalVisible(true);
  };

  const closeModal = () => {
    setModalVisible(false);
    setSelectedPhoto(null);
  };

  if (!photos || photos.length === 0) {
    return null;
  }

  return (
    <View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View className="flex-row">
          {photos.map((photo, index) => (
            <TouchableOpacity
              key={photo.id}
              onPress={() => openModal(photo)}
              className="mr-2">
              <Image
                source={{uri: photo.uri}}
                className="w-24 h-24 rounded-lg"
                resizeMode="cover"
              />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <Modal
        visible={modalVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={closeModal}>
        <View className="flex-1 bg-black bg-opacity-90 justify-center items-center">
          <TouchableOpacity
            onPress={closeModal}
            className="absolute top-12 right-6 z-10">
            <Text className="text-white text-2xl font-bold">×</Text>
          </TouchableOpacity>

          {selectedPhoto && (
            <Image
              source={{uri: selectedPhoto.uri}}
              className="w-full h-3/4"
              resizeMode="contain"
            />
          )}
        </View>
      </Modal>
    </View>
  );
};
