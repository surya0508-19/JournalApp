import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

export const TagInput = ({tags, onTagsChange, placeholder = 'Add tags...'}) => {
  const [inputValue, setInputValue] = useState('');

  const handleAddTag = () => {
    const tag = inputValue.trim().toLowerCase();
    if (tag && !tags.includes(tag)) {
      onTagsChange([...tags, tag]);
      setInputValue('');
    }
  };

  const handleRemoveTag = tagToRemove => {
    onTagsChange(tags.filter(tag => tag !== tagToRemove));
  };

  const handleSubmit = () => {
    if (inputValue.trim()) {
      handleAddTag();
    }
  };

  return (
    <View>
      <View className="flex-row items-center border border-gray-300 rounded-lg">
        <TextInput
          className="flex-1 px-3 py-2 text-base"
          placeholder={placeholder}
          value={inputValue}
          onChangeText={setInputValue}
          onSubmitEditing={handleSubmit}
          returnKeyType="done"
        />
        <TouchableOpacity onPress={handleAddTag} className="px-3 py-2">
          <Text className="text-blue-500 font-medium">Add</Text>
        </TouchableOpacity>
      </View>

      {tags.length > 0 && (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          className="mt-2">
          <View className="flex-row">
            {tags.map((tag, index) => (
              <View
                key={index}
                className="bg-blue-100 px-3 py-1 rounded-full mr-2 flex-row items-center">
                <Text className="text-blue-800 text-sm">#{tag}</Text>
                <TouchableOpacity
                  onPress={() => handleRemoveTag(tag)}
                  className="ml-2">
                  <Text className="text-blue-800 text-sm font-bold">×</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        </ScrollView>
      )}
    </View>
  );
};
