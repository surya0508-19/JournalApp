import React, {useState} from 'react';
import {View, Text, TouchableOpacity, Alert, Linking} from 'react-native';
import {locationService} from '../services/locationService';

export const LocationSelector = ({location, onLocationChange}) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleGetCurrentLocation = async () => {
    try {
      setIsLoading(true);

      // Check permission first
      const hasPermission = await locationService.checkLocationPermission();

      if (!hasPermission) {
        const granted = await locationService.requestLocationPermission(
          'Location permission is required to automatically add your location to entries. Please enable location access in your device settings.',
        );
        if (!granted) {
          Alert.alert(
            'Permission Required',
            'Location permission is required to automatically add your location to entries. Please enable location access in your device settings.',
            [
              {text: 'Cancel', style: 'cancel'},
              {
                text: 'Settings',
                onPress: () => {
                  // You could add Linking.openSettings() here to open app settings
                  console.log(
                    'User should go to settings to enable location permission',
                  );

                  Linking.openSettings();
                },
              },
            ],
          );
          return;
        }
      }

      const currentLocation = await locationService.getCurrentLocation();
      console.log('currentLocationddddd', currentLocation);
      onLocationChange(currentLocation);
    } catch (error) {
      console.error('Location error:', error);
      Alert.alert(
        'Location Error',
        error.message ||
          'Failed to get current location. Please check your location settings and try again.',
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearLocation = () => {
    onLocationChange(null);
  };

  return (
    <View>
      {location ? (
        <View className="border border-gray-300 rounded-lg p-3">
          <View className="flex-row items-center justify-between">
            <View className="flex-1">
              <Text className="text-base text-gray-900 mb-1">
                📍 {locationService.formatLocation(location)}
              </Text>
              {location.address && (
                <Text className="text-sm text-gray-500">
                  {location.address}
                </Text>
              )}
            </View>
            <TouchableOpacity onPress={handleClearLocation} className="ml-2">
              <Text className="text-red-500 text-sm">Remove</Text>
            </TouchableOpacity>
          </View>
        </View>
      ) : (
        <TouchableOpacity
          onPress={handleGetCurrentLocation}
          disabled={isLoading}
          className="border border-gray-300 rounded-lg p-3 flex-row items-center justify-center">
          <Text className="text-gray-600 mr-2">
            {isLoading ? 'Getting location...' : '📍 Add current location'}
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
};
