import React from 'react';
import {Text} from 'react-native';

export const TabBarIcon = ({route, focused, color, size}) => {
  const getIcon = () => {
    switch (route.name) {
      case 'Journal':
        return focused ? '📖' : '📔';
      case 'Search':
        return focused ? '🔍' : '🔎';
      case 'Profile':
        return focused ? '👤' : '👥';
      default:
        return '📄';
    }
  };

  return <Text style={{fontSize: size, color}}>{getIcon()}</Text>;
};
