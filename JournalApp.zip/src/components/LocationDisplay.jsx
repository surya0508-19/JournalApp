import React from 'react';
import {View, Text, TouchableOpacity, Alert} from 'react-native';
import {locationService} from '../services/locationService';

export const LocationDisplay = ({location}) => {
  if (!location) {
    return null;
  }

  const handleOpenMaps = () => {
    // This would open the location in the device's maps app
    // For now, we'll just show an alert
    Alert.alert(
      'Open in Maps',
      `Would you like to open this location in Maps?\n\n${locationService.formatLocation(
        location,
      )}`,
    );
  };

  return (
    <TouchableOpacity
      onPress={handleOpenMaps}
      className="bg-gray-50 border border-gray-200 rounded-lg p-3">
      <View className="flex-row items-center">
        <Text className="text-lg mr-2">📍</Text>
        <View className="flex-1">
          <Text className="text-base text-gray-900">
            {locationService.formatLocation(location)}
          </Text>
          {location.address && (
            <Text className="text-sm text-gray-500 mt-1">
              {location.address}
            </Text>
          )}
        </View>
        <Text className="text-blue-500 text-sm">View on Maps</Text>
      </View>
    </TouchableOpacity>
  );
};
