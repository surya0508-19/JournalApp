import React from 'react';
import {TouchableOpacity, Text} from 'react-native';

export const FloatingActionButton = ({onPress}) => {
  return (
    <TouchableOpacity
      onPress={onPress}
      className="absolute bottom-6 right-6 w-14 h-14 bg-blue-500 rounded-full items-center justify-center shadow-lg"
      style={{
        shadowColor: '#000',
        shadowOffset: {
          width: 0,
          height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
      }}>
      <Text className="text-white text-2xl font-bold">+</Text>
    </TouchableOpacity>
  );
};
