import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  Alert,
  ScrollView,
} from 'react-native';
import {photoService} from '../services/photoService';

export const PhotoSelector = ({
  photos,
  onAddPhotos,
  onRemovePhoto,
  maxPhotos = 5,
}) => {
  const handleAddFromCamera = async () => {
    try {
      const newPhotos = await photoService.takePhoto();
      if (newPhotos.length > 0) {
        onAddPhotos(newPhotos);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to take photo');
    }
  };

  const handleAddFromGallery = async () => {
    try {
      const remainingSlots = maxPhotos - photos.length;
      const newPhotos = await photoService.selectMultipleFromGallery(
        remainingSlots,
      );
      if (newPhotos.length > 0) {
        onAddPhotos(newPhotos);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to select photos');
    }
  };

  const handleAddPhotos = () => {
    Alert.alert('Add Photos', 'Choose how you want to add photos', [
      {text: 'Cancel', style: 'cancel'},
      {text: 'Camera', onPress: handleAddFromCamera},
      {text: 'Gallery', onPress: handleAddFromGallery},
    ]);
  };

  return (
    <View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View className="flex-row">
          {photos.map(photo => (
            <View key={photo.id} className="relative mr-2">
              <Image
                source={{uri: photo.uri}}
                className="w-20 h-20 rounded-lg"
                resizeMode="cover"
              />
              <TouchableOpacity
                onPress={() => onRemovePhoto(photo.id)}
                className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full items-center justify-center">
                <Text className="text-white text-xs font-bold">×</Text>
              </TouchableOpacity>
            </View>
          ))}

          {photos.length < maxPhotos && (
            <TouchableOpacity
              onPress={handleAddPhotos}
              className="w-20 h-20 border-2 border-dashed border-gray-300 rounded-lg items-center justify-center">
              <Text className="text-gray-400 text-2xl">+</Text>
              <Text className="text-gray-400 text-xs mt-1">Add</Text>
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>

      <Text className="text-sm text-gray-500 mt-2">
        {photos.length}/{maxPhotos} photos
      </Text>
    </View>
  );
};
