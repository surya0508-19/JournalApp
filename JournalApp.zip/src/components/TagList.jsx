import React from 'react';
import {View, Text, ScrollView} from 'react-native';

export const TagList = ({tags}) => {
  if (!tags || tags.length === 0) {
    return null;
  }

  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
      <View className="flex-row">
        {tags.map((tag, index) => (
          <View key={index} className="bg-blue-100 px-3 py-1 rounded-full mr-2">
            <Text className="text-blue-800 text-sm">#{tag}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
};
