import React, {useState} from 'react';
import {
  View,
  Text,
  Modal,
  TouchableOpacity,
  ScrollView,
  TextInput,
} from 'react-native';

export const FilterModal = ({visible, filters, onApplyFilters, onClose}) => {
  const [localFilters, setLocalFilters] = useState(filters);

  const handleApply = () => {
    onApplyFilters(localFilters);
  };

  const handleClear = () => {
    setLocalFilters({
      keywords: '',
      tags: [],
      dateRange: null,
      location: null,
    });
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet">
      <View className="flex-1 bg-white">
        {/* Header */}
        <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
          <TouchableOpacity onPress={onClose}>
            <Text className="text-blue-500 text-base">Cancel</Text>
          </TouchableOpacity>
          <Text className="text-lg font-semibold">Filters</Text>
          <TouchableOpacity onPress={handleApply}>
            <Text className="text-blue-500 text-base font-medium">Apply</Text>
          </TouchableOpacity>
        </View>

        <ScrollView className="flex-1 p-4">
          {/* Keywords */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 mb-2">
              Keywords
            </Text>
            <TextInput
              className="border border-gray-300 rounded-lg px-4 py-3 text-base"
              placeholder="Search in title and description..."
              value={localFilters.keywords}
              onChangeText={text =>
                setLocalFilters({...localFilters, keywords: text})
              }
            />
          </View>

          {/* Tags */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 mb-2">
              Tags
            </Text>
            <TextInput
              className="border border-gray-300 rounded-lg px-4 py-3 text-base"
              placeholder="Enter tags separated by commas..."
              value={localFilters.tags.join(', ')}
              onChangeText={text => {
                const tags = text
                  .split(',')
                  .map(tag => tag.trim().toLowerCase())
                  .filter(tag => tag.length > 0);
                setLocalFilters({...localFilters, tags});
              }}
            />
          </View>

          {/* Date Range */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 mb-2">
              Date Range
            </Text>
            <View className="flex-row space-x-3">
              <View className="flex-1">
                <Text className="text-sm text-gray-600 mb-1">From</Text>
                <TouchableOpacity className="border border-gray-300 rounded-lg px-4 py-3">
                  <Text className="text-gray-500">Select start date</Text>
                </TouchableOpacity>
              </View>
              <View className="flex-1">
                <Text className="text-sm text-gray-600 mb-1">To</Text>
                <TouchableOpacity className="border border-gray-300 rounded-lg px-4 py-3">
                  <Text className="text-gray-500">Select end date</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>

          {/* Location */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 mb-2">
              Location
            </Text>
            <TouchableOpacity className="border border-gray-300 rounded-lg px-4 py-3">
              <Text className="text-gray-500">Search by location</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>

        {/* Footer */}
        <View className="p-4 border-t border-gray-200">
          <TouchableOpacity
            onPress={handleClear}
            className="bg-gray-100 py-3 rounded-lg mb-3">
            <Text className="text-gray-700 text-center font-medium">
              Clear All Filters
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};
