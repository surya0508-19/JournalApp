import React, { useEffect } from 'react';
import { StatusBar, useColorScheme } from 'react-native';
import { Provider, useDispatch } from 'react-redux';
import { store, AppDispatch } from './src/store';
import { AppNavigator } from './src/navigation/AppNavigator';
import { databaseService } from './src/services/databaseService';
import { syncService } from './src/services/syncService';
import { checkAuthState } from './src/store/slices/authSlice';

const AppContent = () => {
  const isDarkMode = useColorScheme() === 'dark';
  const dispatch = useDispatch<typeof AppDispatch>();

  useEffect(() => {
    initializeApp();
  }, []);

  const initializeApp = async () => {
    try {
      // Initialize database
      await databaseService.initializeDatabase();
      console.log('Database initialized');

      // Check authentication state using Redux
      try {
        const result = await dispatch(checkAuthState()).unwrap();
        if (result) {
          console.log('User authenticated:', result.email);
        } else {
          console.log('No authenticated user found');
        }
      } catch (error) {
        console.log('Authentication check failed:', error);
      }

      // Check sync status
      const syncStatus = await syncService.getSyncStatus();
      console.log('Sync status:', syncStatus);

    } catch (error) {
      console.error('App initialization error:', error);
    }
  };

  return (
    <>
      <StatusBar
        barStyle={isDarkMode ? 'light-content' : 'dark-content'}
        backgroundColor={isDarkMode ? '#0f172a' : '#f8fafc'}
      />
      <AppNavigator />
    </>
  );
};

function App() {
  return (
    <Provider store={store}>
      <AppContent />
    </Provider>
  );
}

export default App;